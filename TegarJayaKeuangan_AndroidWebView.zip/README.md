# Tegar Jaya Keuangan — Android WebView

Project Android WebView lengkap dari demo `TegarJayaKeuangan_Demo.html`.

## Build lokal
Buka folder ini di Android Studio, tunggu Gradle sync, lalu Build > Build APK(s).

## Build GitHub Actions
Workflow tersedia di `.github/workflows/build-apk.yml`.
Commit project ke repository GitHub, lalu buka Actions > Build APK > Run workflow.

APK debug akan tersedia sebagai artifact `TegarJayaKeuangan-APK`.
